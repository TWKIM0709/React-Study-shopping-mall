import { Col, Container, Row } from "react-bootstrap";

function Detail(){
    return(
        <>
            <h1>Detail Page</h1>
            <Container>
                <Row>
                    <Col ></Col>
                    <Col></Col>
                </Row>
            </Container>
        </>
    )
}
export default Detail;