let data = [
	{
	    "title" : 'Akkawi Cheese',
	    "imgsrc" : "https://upload.wikimedia.org/wikipedia/commons/thumb/4/4e/Akawi_Cheese.jpg/203px-Akawi_Cheese.jpg",
  	    "content" : "Akkawi Cheese Info",
	    "price" : 90000
	},
	{
	    "title" : 'Anari Cheese',
	    "imgsrc" : "https://upload.wikimedia.org/wikipedia/commons/thumb/1/1c/Anari_Limassol.jpg/203px-Anari_Limassol.jpg",
  	    "content" : "Anari Cheese Info",
	    "price" : 120000
	},
	{
	    "title" : 'Halloumi Cheese',
	    "imgsrc" : "https://upload.wikimedia.org/wikipedia/commons/thumb/3/30/Grilled_Halloumi.jpg/203px-Grilled_Halloumi.jpg",
  	    "content" : "Halloumi Cheese Info",
	    "price" : 70000
	}
];
export default data;