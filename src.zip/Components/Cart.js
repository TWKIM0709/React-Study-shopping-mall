function Cart(){
    return(
        <>
            <h1>Cart Page</h1>
            <p>CCCCCCCCCCCCaaaaaaaaaaaarrrrrrrrrrtttttttt</p>
        </>
    )
}
export default Cart;