import './App.css';
import './css/main.css';
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import { Col, Row } from 'react-bootstrap';
import data from './data';
import { useState } from 'react';
import { Outlet, Route, Routes } from 'react-router-dom';
import Detail from './Components/Detail';
import Cart from './Components/Cart';
import Event from './Components/Event';

function App() {

  let [cheese]= useState(data);


  return (
    <div className="App">
        {/* NavBar */}
        <NavArea/>
        {/* 점보트론 */}
        <MainTitle/>
        {/* Content */}
        {/* <CardContent cheese={cheese}/> */}
        {/* 라우터를 이용한 페이지 스왑? */}
        <Routes>
            <Route path='/' element={<CardContent cheese={cheese}/>}/>
            <Route path='/detail' element={<Detail/>}/>
            <Route path='/cart' element={<Cart/>}/>
            <Route path='/about' element={<About/>}>
                <Route path='emp' element={<div>너는 우리 직원이야</div>}/>
                <Route path='location' element={<div>혜화역 4번 출구</div>}/>
            </Route>
            <Route path='/event' element={<Event/>}>
                <Route path='one' element={<div>첫 주문은 1+1입니다.</div>}/>
                <Route path='two' element={<div>포인트 1,0000점을 드립니다.</div>}/>
            </Route>
            {/* 에러페이지 만들기 */}
            <Route path='*' element={<h1>없는 페이지 입니다.</h1>}/>
        </Routes>
    </div>
  );
} //end App

export default App;

function CardContent({cheese}){
  return <Container id="cheeseMain">
    <Row>
        {
            cheese.map((data,index)=>
                <Col lg={4} md={4} sm={6} xs={6} className='cheeseImage' key={index}>
                    <a href={`/detail?no=${index}`}> {/*  {`/detail?no=${index}`} */}
                        <img src={data.imgsrc} alt={data.title}/>
                    </a>
                    <h4>{data.title}</h4>
                    <p>{data.content}</p>
                    <p>{data.price}</p>
                </Col>
                )
        }
    </Row>
  </Container>
} //end CardContent

function NavArea(){
  return <Navbar bg="light" expand="lg">
  <Container>
    <Navbar.Brand href="/">KOSAShop</Navbar.Brand>
    <Navbar.Toggle aria-controls="basic-navbar-nav" />
    <Navbar.Collapse id="basic-navbar-nav">
      <Nav className="me-auto">
        <Nav.Link href="/">Home</Nav.Link>
        <Nav.Link href="/cart">Cart</Nav.Link>
        <NavDropdown title="About" id="basic-nav-dropdown">
          <NavDropdown.Item href="/about/emp">Emp</NavDropdown.Item>
          <NavDropdown.Item href="/about/location">Location</NavDropdown.Item>
          {/* <NavDropdown.Divider />
          <NavDropdown.Item href="#action/3.4">
            Separated link
          </NavDropdown.Item> */}
        </NavDropdown>
        <NavDropdown title="Event" id="basic-nav-dropdown">
          <NavDropdown.Item href="/event/one">One</NavDropdown.Item>
          <NavDropdown.Item href="/event/two">Two</NavDropdown.Item>
        </NavDropdown>
      </Nav>
    </Navbar.Collapse>
  </Container>
</Navbar>
}// end NavArea

function MainTitle(){
  return <div className="jumbotron">
                <img src='https://han.gl/nrZOd' alt='Cheese' className='titleImage'/>
                  <h1 className="display-4">Cheese</h1>
                  <p className="lead">The nutritional value of cheese varies widely. Cottage cheese may consist of 4% fat and 11% protein while some whey cheeses are 15% fat and 11% protein, and triple-crème cheeses are 36% fat and 7% protein.</p>
                  <hr className="my-4"/>
                  <p>A cheeseboard (or cheese course) may be served at the end of a meal before or following dessert, or replacing the last course. </p>
                  <a className="btn btn-primary btn-lg" href="#cheeseMain" role="button">More Cheese</a>
                </div>
} //end MainTitle

function About(){
    return(
        <>
            <h1>About Page</h1>
            <Outlet></Outlet>
        </>
    )
} //end About